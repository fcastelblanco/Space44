export interface Movie {
    title?: string;
    releaseYear?: string;
    productionCompany?: string;
    director?: string;
    writer?: string;
    actorOne?: string;
    actorTwo?: string;
    actorThree?: string;
    location?: string;
}
