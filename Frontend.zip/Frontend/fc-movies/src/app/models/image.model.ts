export interface Image{
    name: string;
    size: number;
    extension: string;
    content: string;
    id: string;
}