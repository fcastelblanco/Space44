import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Movie } from '../models/movie.model';
import { Observable, Observer } from 'rxjs';

@Injectable()
export class MovieService {
  geocoder: google.maps.Geocoder;

  constructor(private http: HttpClient) {
    this.geocoder = new google.maps.Geocoder();
  }

  getMovies() {
    return this.http.get<Movie[]>(`${environment.apiMovies}/movie`);
  }

  getMoviesByLocation(address: string) {
    return this.http.get<Movie[]>(`${environment.apiMovies}/movie/${address}`);
  }

  codeAddress(address: string): Observable<google.maps.GeocoderResult[]> {
    return Observable.create(
      (observer: Observer<google.maps.GeocoderResult[]>) => {
        this.geocoder.geocode(
          { address: address },
          (
            results: google.maps.GeocoderResult[],
            status: google.maps.GeocoderStatus
          ) => {
            if (status === google.maps.GeocoderStatus.OK) {
              observer.next(results);
              observer.complete();
            } else {              
              observer.error(status);
            }
          }
        );
      }
    );
  }
}
