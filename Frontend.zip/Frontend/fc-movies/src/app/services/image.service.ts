import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Image } from '../models/image.model';

@Injectable()
export class ImageService {  

  constructor(private http: HttpClient) {
    
  }

  upload(formData: FormData) {
    return this.http.post(`${environment.apiMovies}/image/`, formData)
  }

  delete(id: string) {
    return this.http.delete(`${environment.apiMovies}/image/${id}`);
  }

  getAll(){
    return this.http.get<Image[]>(`${environment.apiMovies}/image/`);
  }
  
}
