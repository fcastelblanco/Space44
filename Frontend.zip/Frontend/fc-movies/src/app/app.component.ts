import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  isCollapsed = true;

  constructor(public route: ActivatedRoute) {

  }

  

 toggleMenu() {
    this.isCollapsed = !this.isCollapsed;
  }

 
}
