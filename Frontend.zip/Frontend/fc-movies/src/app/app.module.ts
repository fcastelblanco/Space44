import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieModule } from './movie/movie.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MovieService } from './services/movie.service';
import { HttpClientModule } from '@angular/common/http';
import { ManagerComponent } from './image/manager/manager.component';
import { ImageService } from './services/image.service';

@NgModule({
  declarations: [
    AppComponent,
    ManagerComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MovieModule,
    NgbModule,
    HttpClientModule
  ],
  providers: [MovieService, ImageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
