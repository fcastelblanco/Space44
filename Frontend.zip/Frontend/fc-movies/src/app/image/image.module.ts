import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ImageRoutingModule } from './image-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ImageRoutingModule
  ]
})
export class ImageModule { }
