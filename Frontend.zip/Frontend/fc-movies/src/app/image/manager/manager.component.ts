
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { Image } from 'src/app/models/image.model';
import { ImageService } from 'src/app/services/image.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.scss'],
})
export class ManagerComponent implements OnInit {
  ngOnInit(): void {}

  file: undefined | File;
  fileName: string = '';
  imageList: Observable<Image[]>;

  constructor(private imageService: ImageService, private _sanitizer: DomSanitizer) {    
    this.imageList = this.imageService.getAll();
  }

  onFileSelected(event: any) {
    this.file = event.target.files[0];

    if (this.file) {
      this.fileName = this.file.name;
    }
  }

  upload() {
    const formData = new FormData();
    formData.append(this.fileName, this.file as File);
    this.imageService.upload(formData).subscribe((res) => {
      this.imageList = this.imageService.getAll();
    });
  }

  delete(id: string){
    this.imageService.delete(id).subscribe((res) => {
      this.imageList = this.imageService.getAll();
    });
  }

  resolveSrc(content: string){
    return this._sanitizer.bypassSecurityTrustResourceUrl(`data:image/jpg;base64,${content}`);
  }
}
