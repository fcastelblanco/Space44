import { Observable, of, pipe } from 'rxjs';
import { Component, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Movie } from 'src/app/models/movie.model';
import { MovieService } from 'src/app/services/movie.service';
import { FormBuilder, FormControl } from '@angular/forms';
import { GoogleMap, MapInfoWindow, MapMarker } from '@angular/google-maps';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-searcher',
  templateUrl: './searcher.component.html',
  styleUrls: ['./searcher.component.scss'],
})
export class SearcherComponent implements OnInit, OnDestroy {
  movies: Observable<Movie[]>;
  theMovieSelected: undefined | Movie;
  addressForm = this.formBuilder.group({
    address: new FormControl(''),
  });
  geocoder: google.maps.Geocoder;
  timeOut: any;

  @ViewChild(google.maps.Map, { static: false }) map:
    | undefined
    | google.maps.Map;
  @ViewChild(MapInfoWindow, { static: false }) info: undefined | MapInfoWindow;

  zoom = 12;
  center: undefined | google.maps.LatLngLiteral;
  options: google.maps.MapOptions = {
    zoomControl: true,
    scrollwheel: true,    
    mapTypeId: 'hybrid',
    maxZoom: 15,
    minZoom: 8,
  };
  markers: google.maps.Marker[];
  infoContent = '';

  constructor(
    private movieService: MovieService,
    private formBuilder: FormBuilder
  ) {
    this.movies = new Observable<Movie[]>();
    this.geocoder = new google.maps.Geocoder();
    this.markers = [];

    navigator.geolocation.getCurrentPosition((position) => {
      this.center = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
      };
    });

    this.addressForm.get('address')?.valueChanges.subscribe((selectedValue) => {
      const theAddressValue = this.addressForm.get('address')?.value as string;

      if (theAddressValue) {
        clearTimeout(this.timeOut);
        this.timeOut = setTimeout(() => {
          this.movies = this.movieService.getMoviesByLocation(theAddressValue);
        }, 500);
      }
    });
  }

  ngOnDestroy(): void {}

  ngOnInit(): void {}

  movieSelected(movie: Movie) {
    this.movies = new Observable<Movie[]>();
    this.addressForm.get('address')?.setValue('');
    this.theMovieSelected = movie;
    this.addMarker();

    this.movieService
      .codeAddress(this.theMovieSelected.location as string)
      .forEach((results: google.maps.GeocoderResult[]) => {
        const coordinates = this.center as google.maps.LatLngLiteral;
        const location = results[0].geometry.location;

        if (
          coordinates.lat !== location.lat() &&
          coordinates.lng != location.lng()
        ) {
          this.center = {
            lat: results[0].geometry.location.lat(),
            lng: results[0].geometry.location.lng(),
          };

          (this.map as google.maps.Map).setCenter(this.center);
          this.addMarker();
        }
      })
      .then(() => {
        console.log('Geocoding service: completed.');
      })
      .catch((error: google.maps.GeocoderStatus) => {
        if (error === google.maps.GeocoderStatus.ZERO_RESULTS) {
          console.log(error);
        }
      });
  }

  addMarker() {   

    var marker = new google.maps.Marker({
      position: this.center,
      map: this.map,
      title: this.theMovieSelected?.location,
    });

    this.markers.push(marker);
  }
}
